import React from "react";
import "./controlbar.scss";
export interface ControlBarProps {
    children: any;
    type: string;
}
export declare const ControlBar: ({ children, type }: ControlBarProps) => React.JSX.Element;
