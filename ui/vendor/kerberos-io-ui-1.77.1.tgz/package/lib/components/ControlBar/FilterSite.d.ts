import React from "react";
import "./controlbar.scss";
export interface FilterSiteProps {
    children: any;
}
export declare const FilterSite: ({ children }: FilterSiteProps) => React.JSX.Element;
