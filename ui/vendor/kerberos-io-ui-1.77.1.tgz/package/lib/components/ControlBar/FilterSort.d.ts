import React from "react";
import "./controlbar.scss";
export interface FilterSortProps {
    children: any;
}
export declare const FilterSort: ({ children }: FilterSortProps) => React.JSX.Element;
