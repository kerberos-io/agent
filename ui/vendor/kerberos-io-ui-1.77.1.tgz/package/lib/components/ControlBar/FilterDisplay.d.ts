import React from "react";
import "./controlbar.scss";
export interface FilterDisplayProps {
    children: any;
}
export declare const FilterDisplay: ({ children }: FilterDisplayProps) => React.JSX.Element;
