import React from "react";
import "./controlbar.scss";
export interface FilterSearchProps {
    children: any;
}
export declare const FilterSearch: ({ children }: FilterSearchProps) => React.JSX.Element;
