import React from "react";
import "./modal.scss";
export interface ModalFooterProps {
    left?: any;
    right?: any;
}
export declare const ModalFooter: ({ left, right }: ModalFooterProps) => React.JSX.Element;
