import React from "react";
import "./modal.scss";
export interface ModalBodyProps {
    children: any;
}
export declare const ModalBody: ({ children }: ModalBodyProps) => React.JSX.Element;
