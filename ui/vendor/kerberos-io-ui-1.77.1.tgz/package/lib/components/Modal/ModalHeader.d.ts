import React from "react";
import "./modal.scss";
export interface ModalHeaderProps {
    title: string;
    subtitle: string;
    onClose?: (event: React.MouseEvent<HTMLDivElement, MouseEvent>) => void;
}
export declare const ModalHeader: ({ title, subtitle, onClose }: ModalHeaderProps) => React.JSX.Element;
