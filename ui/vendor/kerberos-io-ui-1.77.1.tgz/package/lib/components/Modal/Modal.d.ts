import React from "react";
import "./modal.scss";
export interface ModalProps {
    children: any;
    direction: "left" | "right";
    search?: boolean;
    maxWidth: string;
}
export declare const Modal: ({ children, direction, maxWidth, search }: ModalProps) => React.JSX.Element;
