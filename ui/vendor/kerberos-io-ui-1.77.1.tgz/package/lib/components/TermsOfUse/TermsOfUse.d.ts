import React from "react";
import "./termsofuse.scss";
export interface TermsOfUseProps {
    text: string;
    href: string;
}
declare const TermsOfUse: ({ text, href }: TermsOfUseProps) => React.JSX.Element;
export default TermsOfUse;
