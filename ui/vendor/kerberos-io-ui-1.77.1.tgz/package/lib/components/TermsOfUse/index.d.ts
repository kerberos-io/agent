export { default } from "./TermsOfUse";
