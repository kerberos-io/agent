import React from "react";
import "./dropdown.scss";
export interface DropdownProps {
    placeholder: string;
    icon: string;
    selected: any;
    items: any;
    direction: "left" | "right";
    search?: boolean;
    shorten?: boolean;
    shortenType?: string;
    shortenMaxLength?: number;
    label?: string;
    layout?: "form" | "controlbar";
    isRadio?: boolean;
    absolute?: boolean;
    onChange: any;
    error?: string;
}
export declare const Dropdown: ({ placeholder, icon, selected, items, direction, search, label, absolute, shorten, shortenType, shortenMaxLength, layout, error, isRadio, onChange }: DropdownProps) => React.JSX.Element;
