import React from "react";
import "./dropdown.scss";
export interface DropListProps {
    title: string;
    value: string;
    radio?: boolean;
    icon?: string;
    checked?: boolean;
    onChange?: any;
    shorten?: boolean;
    shortenType?: string;
    shortenMaxLength?: number;
}
export declare const DropList: ({ title, value, radio, icon, checked, shorten, shortenType, shortenMaxLength, onChange, }: DropListProps) => React.JSX.Element;
