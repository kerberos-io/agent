import React from "react";
import "./profilebar.scss";
export interface ProfilebarProps {
    username: string;
    email: string;
    userrole: string;
    gravatarSize?: string;
    active?: boolean;
    logout?: any;
}
declare const Profilebar: ({ username, email, userrole, gravatarSize, active, logout, }: ProfilebarProps) => React.JSX.Element;
export default Profilebar;
