import React from "react";
import "./infobox.scss";
export interface InfoBoxProps {
    image: string;
    title: string;
    description?: string;
    onClick?: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
}
declare const InfoBox: ({ image, title, description, onClick, }: InfoBoxProps) => React.JSX.Element;
export default InfoBox;
