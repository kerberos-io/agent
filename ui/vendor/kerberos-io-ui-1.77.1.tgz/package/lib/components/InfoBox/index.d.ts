export { default } from "./InfoBox";
