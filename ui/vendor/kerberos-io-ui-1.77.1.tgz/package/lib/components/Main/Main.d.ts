import React from "react";
import "./main.scss";
export interface MainProps {
    children?: any;
}
declare const Main: ({ children, }: MainProps) => React.JSX.Element;
export default Main;
