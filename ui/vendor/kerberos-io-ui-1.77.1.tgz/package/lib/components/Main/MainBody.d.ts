import React from "react";
import "./main.scss";
export interface MainBodyProps {
    children?: any;
}
declare const MainBody: ({ children, }: MainBodyProps) => React.JSX.Element;
export default MainBody;
