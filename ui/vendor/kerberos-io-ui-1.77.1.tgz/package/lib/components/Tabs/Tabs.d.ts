import React from "react";
import "./tabs.scss";
export interface TabsProps {
    children?: any;
}
export declare const Tabs: ({ children, }: TabsProps) => React.JSX.Element;
