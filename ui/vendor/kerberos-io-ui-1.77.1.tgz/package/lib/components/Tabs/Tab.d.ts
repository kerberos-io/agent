import React from "react";
import "./tabs.scss";
export interface TabProps {
    onClick: any;
    label: any;
    value: any;
    icon: any;
    active: boolean;
}
export declare const Tab: ({ onClick, label, value, icon, active, }: TabProps) => React.JSX.Element;
