import React from "react";
import "./alert.scss";
export interface ALertProps {
    status: string;
    platter?: boolean;
    notify?: boolean;
    blink?: boolean;
    onClick?: (event: React.MouseEvent<HTMLDivElement, MouseEvent>) => void;
}
declare const ALert: ({ status, platter, notify, blink, onClick }: ALertProps) => React.JSX.Element;
export default ALert;
