import "./footer.scss";
import React from "react";
export interface FooterCopyrightProps {
    title: string;
    description: string;
    description2: string;
    socials: {
        label: string;
        href: string;
    }[];
}
declare const FooterCopyright: ({ title, description, description2, socials }: FooterCopyrightProps) => React.JSX.Element;
export default FooterCopyright;
