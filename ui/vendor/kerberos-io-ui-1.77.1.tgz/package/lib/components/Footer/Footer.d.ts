import React from "react";
import "./footer.scss";
export interface FooterProps {
    children?: any;
}
declare const Footer: ({ children }: FooterProps) => React.JSX.Element;
export default Footer;
