import React from "react";
import "./footer.scss";
export interface FooterProps {
    title: string;
    items: {
        item?: string;
        href?: string;
    }[];
}
declare const FooterList: ({ title, items }: FooterProps) => React.JSX.Element;
export default FooterList;
