import React from "react";
import "./table.scss";
export interface TableRowProps {
    id: string;
    columnName?: string;
    headercells?: any[];
    bodycells?: any[];
    details?: any;
    showDetails?: boolean;
}
export declare const TableRow: ({ id, columnName, headercells, bodycells, details, showDetails }: TableRowProps) => React.JSX.Element;
