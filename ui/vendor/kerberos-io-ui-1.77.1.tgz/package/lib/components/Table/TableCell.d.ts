import React from "react";
import "./table.scss";
export interface TableCellProps {
    children: any;
}
export declare const TableCell: ({ children }: TableCellProps) => React.JSX.Element;
