import React from "react";
export interface CamerasRowProps {
    status: string;
    statusTitle: string;
    name: string;
    nameStatus: string;
    city: string;
    state: string;
    time: any;
    version: any;
    isOffline: boolean;
    isEnterperise?: boolean;
}
export declare const CamerasRow: ({ status, statusTitle, name, nameStatus, city, state, time, version, isOffline, isEnterperise }: CamerasRowProps) => React.JSX.Element;
