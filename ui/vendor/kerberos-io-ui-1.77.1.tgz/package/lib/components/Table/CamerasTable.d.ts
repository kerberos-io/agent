import React from "react";
export interface CamarasTableProps {
    children: any;
}
export declare const CamerasTable: ({ children }: CamarasTableProps) => React.JSX.Element;
