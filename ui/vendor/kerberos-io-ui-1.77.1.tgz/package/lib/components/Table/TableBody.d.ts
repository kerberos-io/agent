import React from "react";
import "./table.scss";
export interface TableBodyProps {
    children: any;
}
export declare const TableBody: ({ children }: TableBodyProps) => React.JSX.Element;
