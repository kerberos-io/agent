import React from "react";
import "./table.scss";
export interface TableProps {
    children: any;
}
export declare const Table: ({ children, }: TableProps) => React.JSX.Element;
