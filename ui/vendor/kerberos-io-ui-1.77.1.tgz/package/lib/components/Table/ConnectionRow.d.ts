import React from "react";
export interface ConnectionRowProps {
    pinStatus: string;
    sitePin: string;
    siteName: string;
    techName: string;
    techContainer: string;
    camStatus: string;
    camDevided: number;
    camDevisor: number;
}
export declare const ConnectionRow: ({ pinStatus, sitePin, siteName, techName, techContainer, camStatus, camDevided, camDevisor }: ConnectionRowProps) => React.JSX.Element;
