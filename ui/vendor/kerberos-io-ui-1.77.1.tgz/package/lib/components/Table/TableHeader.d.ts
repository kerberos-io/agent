import React from "react";
import "./table.scss";
export interface TableHeaderProps {
    children: any;
}
export declare const TableHeader: ({ children }: TableHeaderProps) => React.JSX.Element;
