import React from "react";
import "./setupbox.scss";
export interface SetupBoxProps {
    dashed?: boolean;
    header: string;
    text: string;
    btnicon: string;
    btnlabel: string;
    button?: any;
}
declare const SetupBox: ({ dashed, header, text, btnicon, btnlabel, button }: SetupBoxProps) => React.JSX.Element;
export default SetupBox;
