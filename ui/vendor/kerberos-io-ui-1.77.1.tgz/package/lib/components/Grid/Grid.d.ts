import React from "react";
import "./grid.scss";
export interface GridProps {
    columns?: number;
    placeholderText?: string;
}
declare const Grid: ({ columns }: GridProps) => React.JSX.Element;
export default Grid;
