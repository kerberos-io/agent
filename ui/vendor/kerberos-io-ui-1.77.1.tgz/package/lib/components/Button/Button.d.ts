import React from "react";
import "./button.scss";
export interface ButtonProps {
    label: string;
    icon: string;
    buttonType?: "button" | "submit" | "reset";
    type?: string;
    disabled?: boolean;
    onClick?: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
}
declare const Button: ({ onClick, label, buttonType, type, disabled, icon, }: ButtonProps) => React.JSX.Element;
export default Button;
