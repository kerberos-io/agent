import React from "react";
import "./videocontainer.scss";
export interface VideoContainerProps {
    children?: any;
    cols: string | number;
    isVideoWall: boolean;
}
export declare const VideoContainer: ({ children, cols, isVideoWall }: VideoContainerProps) => React.JSX.Element;
