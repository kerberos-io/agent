import React from "react";
import "./videocontainer.scss";
export interface VideoWallHeaderProps {
    grid: string[] | number[];
    hide?: boolean;
}
export declare const VideoWallHeader: ({ grid, hide }: VideoWallHeaderProps) => React.JSX.Element;
