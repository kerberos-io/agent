import React from "react";
import "./navigation.scss";
export interface NavigationSectionProps {
    title: string;
}
declare const NavigationSection: ({ title, }: NavigationSectionProps) => React.JSX.Element;
export default NavigationSection;
