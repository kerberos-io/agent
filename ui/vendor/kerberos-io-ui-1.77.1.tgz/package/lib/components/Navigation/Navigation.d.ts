import React from "react";
import "./navigation.scss";
export interface NavigationProps {
    children?: any;
}
declare const Navigation: ({ children, }: NavigationProps) => React.JSX.Element;
export default Navigation;
