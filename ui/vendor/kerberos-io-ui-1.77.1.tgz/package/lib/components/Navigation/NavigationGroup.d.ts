import React from "react";
import "./navigation.scss";
export interface NavigationGroupProps {
    children?: any;
}
declare const NavigationGroup: ({ children, }: NavigationGroupProps) => React.JSX.Element;
export default NavigationGroup;
