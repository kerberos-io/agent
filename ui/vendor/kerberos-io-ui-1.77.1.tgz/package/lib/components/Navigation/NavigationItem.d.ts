import React from "react";
import "./navigation.scss";
export interface NavigationItemProps {
    title: string;
    icon: string;
    link?: any;
    external?: boolean;
    active?: boolean;
}
declare const NavigationItem: ({ title, icon, link, external, active, }: NavigationItemProps) => React.JSX.Element;
export default NavigationItem;
