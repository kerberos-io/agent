import React from "react";
import "./breadcrumb.scss";
export interface BreadcrumbProps {
    title: string;
    level1?: string;
    level1Link?: string;
    level2?: string;
    level2Link?: string;
    level3?: string;
    level3Link?: string;
    children?: any;
}
/**
 * Primary UI component for user interaction
 */
declare const Breadcrumb: ({ title, level1, level1Link, level2, level2Link, level3, level3Link, children, }: BreadcrumbProps) => React.JSX.Element;
export default Breadcrumb;
