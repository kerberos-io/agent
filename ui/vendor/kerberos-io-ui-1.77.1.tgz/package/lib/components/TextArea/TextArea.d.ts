import React from "react";
import "./textarea.scss";
export interface TextAreaProps {
    label?: string;
    placeholder?: string;
    value?: string;
    error?: string;
    rows?: number;
    readonly?: boolean;
    readonlyLabel?: boolean;
    disabled?: boolean;
    layout?: "form" | "controlbar";
    onBlur?: (event: React.FormEvent<HTMLTextAreaElement>) => void;
    onChange?: (event: React.FormEvent<HTMLTextAreaElement>) => void;
    onClick?: (event: React.MouseEvent<HTMLTextAreaElement, MouseEvent>) => void;
}
export declare const TextArea: ({ label, placeholder, value, rows, error, readonly, readonlyLabel, disabled, layout, onChange, onClick, ...rest }: TextAreaProps) => React.JSX.Element;
