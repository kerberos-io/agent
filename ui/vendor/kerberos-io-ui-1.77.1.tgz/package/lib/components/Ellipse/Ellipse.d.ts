import React from "react";
import "./ellipse.scss";
export interface EllipseProps {
    status: string;
    aura?: boolean;
    blink?: boolean;
}
declare const Ellipse: ({ status, aura, blink }: EllipseProps) => React.JSX.Element;
export default Ellipse;
