export { default } from "./Ellipse";
