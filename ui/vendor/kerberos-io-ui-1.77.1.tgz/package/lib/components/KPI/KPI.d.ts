import React from "react";
import "./kpi.scss";
export interface KPIProps {
    number?: string;
    divider?: string;
    progress?: string;
    progressValue?: string;
    footer?: string;
}
declare const KPI: ({ number, divider, progress, progressValue, footer }: KPIProps) => React.JSX.Element;
export default KPI;
