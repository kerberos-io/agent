import React from "react";
import "./landinglayout.scss";
export interface LandingLayoutProps {
    children: any;
    title?: string;
    version?: string;
    description?: string;
    hideFooter?: boolean;
}
declare const LandingLayout: ({ children, title, version, description, hideFooter }: LandingLayoutProps) => React.JSX.Element;
export default LandingLayout;
