import React from "react";
import "./sidebar.scss";
export interface SidebarProps {
    logo?: string;
    title?: string;
    version?: string;
    mobile?: boolean;
    children?: any;
}
declare const Sidebar: ({ logo, title, version, mobile, children, }: SidebarProps) => React.JSX.Element;
export default Sidebar;
