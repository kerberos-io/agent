import React from "react";
import "./input.scss";
export interface FieldSetProps {
    children: HTMLInputElement | any;
}
export declare const FieldSet: ({ children }: FieldSetProps) => React.JSX.Element;
