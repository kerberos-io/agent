import React from "react";
import "./input.scss";
export interface InputProps {
    label?: string;
    placeholder?: string;
    value?: string;
    error?: string;
    readonly?: boolean;
    readonlyLabel?: boolean;
    disabled?: boolean;
    hint?: string;
    iconleft?: string;
    iconright?: string;
    seperate?: boolean;
    noPadding?: boolean;
    layout?: "form" | "controlbar";
    type?: string;
    onBlur?: (event: React.FormEvent<HTMLInputElement>) => void;
    onChange?: (event: React.FormEvent<HTMLInputElement>) => void;
    onClick?: (event: React.MouseEvent<HTMLInputElement, MouseEvent>) => void;
}
export declare const Input: ({ label, placeholder, value, error, readonly, readonlyLabel, disabled, hint, layout, iconleft, iconright, seperate, noPadding, type, onChange, onClick, ...rest }: InputProps) => React.JSX.Element;
