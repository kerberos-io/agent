import React from "react";
import "./input.scss";
export interface FormProps {
    children: HTMLFieldSetElement | HTMLInputElement | any;
    onSubmit?: (event: React.SyntheticEvent | any) => void;
}
export declare const Form: ({ children, onSubmit }: FormProps) => React.JSX.Element;
