import React from "react";
import "./badge.scss";
export interface BadgeProps {
    status: string;
    title?: string;
    blink?: boolean;
    aura?: boolean;
    devided?: number;
    devisor?: number;
    round?: boolean;
}
declare const Badge: ({ status, title, blink, aura, devided, devisor, round }: BadgeProps) => React.JSX.Element;
export default Badge;
