import React from "react";
import "./toggle.scss";
export interface ToggleProps {
    on: boolean;
    disabled: boolean;
    onClick: any;
}
declare const Toggle: ({ on, disabled, onClick }: ToggleProps) => React.JSX.Element;
export default Toggle;
