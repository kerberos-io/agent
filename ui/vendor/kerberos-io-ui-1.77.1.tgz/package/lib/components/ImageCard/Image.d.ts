import React from "react";
import "./imagecard.scss";
export interface ImageProps {
    src?: string;
    poster?: string;
}
export declare const Image: ({ src, poster }: ImageProps) => React.JSX.Element;
