import React from "react";
import "./imagecard.scss";
export interface ImageHeaderProps {
    label?: string;
    status: string;
    statusTitle?: string;
}
export declare const ImageHeader: ({ label, status, statusTitle, }: ImageHeaderProps) => React.JSX.Element;
