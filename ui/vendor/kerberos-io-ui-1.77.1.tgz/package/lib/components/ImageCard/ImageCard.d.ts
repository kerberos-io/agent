import React from "react";
import "./imagecard.scss";
export interface ImageCardProps {
    label?: string;
    headerStatus: string;
    headerStatusTitle: string;
    videoStatus: string;
    videoStatusTitle?: string;
    isVideoWall?: boolean;
    isMediaWall?: boolean;
    isOffline?: boolean;
    imageSrc?: string;
    duration?: any;
    month?: any;
    hours?: any;
    camera?: string;
}
export declare const ImageCard: ({ label, headerStatus, headerStatusTitle, videoStatus, videoStatusTitle, isVideoWall, isMediaWall, isOffline, imageSrc, duration, month, hours, camera, }: ImageCardProps) => React.JSX.Element;
