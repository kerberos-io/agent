import React from "react";
import "./imagecard.scss";
export interface ImageToolsProps {
    status: string;
    title?: string;
    duration?: any;
    camera?: string;
    onClickSD?: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
    onClickHD?: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
}
export declare const ImageTools: ({ onClickHD, onClickSD, status, title, duration, camera }: ImageToolsProps) => React.JSX.Element;
