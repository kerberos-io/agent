import React from "react";
import "./card.scss";
export interface CardProps {
    label: string;
    icon: string;
    title: string;
    subtitle: string;
    footer: string;
    type?: string;
    onClick?: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
}
declare const Card: ({ onClick, label, title, subtitle, footer, type, icon, }: CardProps) => React.JSX.Element;
export default Card;
