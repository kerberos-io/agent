import React from "react";
import "./social-list.scss";
export interface SocialListProps {
    list: {
        label: string;
        href: string;
    }[];
}
declare const SocialList: ({ list }: SocialListProps) => React.JSX.Element;
export default SocialList;
