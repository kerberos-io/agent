export { default } from "./SocialList";
