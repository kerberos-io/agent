import React from "react";
import "./alertmessage.scss";
export interface AlertMessageProps {
    message: string;
    onClick?: (event: React.MouseEvent<HTMLDivElement, MouseEvent>) => void;
}
declare const AlertMessage: ({ message, onClick }: AlertMessageProps) => React.JSX.Element;
export default AlertMessage;
