import React from "react";
import "./videocard.scss";
export interface VideoToolsProps {
    status: string;
    title?: string;
    duration?: any;
    camera?: string;
    onClickSD?: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
    onClickHD?: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
}
export declare const VideoTools: ({ onClickHD, onClickSD, status, title, duration, camera }: VideoToolsProps) => React.JSX.Element;
