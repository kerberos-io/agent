import React from "react";
import "./videocard.scss";
export interface VideoCardProps {
    label?: string;
    headerStatus: string;
    headerStatusTitle: string;
    videoStatus: string;
    videoStatusTitle?: string;
    isVideoWall?: boolean;
    isMediaWall?: boolean;
    isOffline?: boolean;
    videoSrc?: string;
    videoPoster?: string;
    duration?: any;
    month?: any;
    hours?: any;
    camera?: string;
    handleClickSD?: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
    handleClickHD?: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
}
export declare const VideoCard: ({ label, headerStatus, headerStatusTitle, videoStatus, videoStatusTitle, isVideoWall, isMediaWall, isOffline, videoSrc, videoPoster, duration, month, hours, camera, handleClickHD, handleClickSD, }: VideoCardProps) => React.JSX.Element;
