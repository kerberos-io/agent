import React from "react";
import "./videocard.scss";
export interface VideoProps {
    src?: string;
    poster?: string;
}
export declare const Video: ({ src, poster }: VideoProps) => React.JSX.Element;
