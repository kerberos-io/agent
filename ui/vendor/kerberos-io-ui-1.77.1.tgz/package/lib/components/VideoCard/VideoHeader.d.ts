import React from "react";
import "./videocard.scss";
export interface VideoHeaderProps {
    label?: string;
    status: string;
    statusTitle?: string;
}
export declare const VideoHeader: ({ label, status, statusTitle, }: VideoHeaderProps) => React.JSX.Element;
