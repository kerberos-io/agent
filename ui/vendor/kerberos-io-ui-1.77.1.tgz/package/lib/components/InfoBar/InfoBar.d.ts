import React from "react";
import "./infobar.scss";
export interface InfoBarProps {
    type: string;
    message: string;
    showClose: boolean;
    onClick?: (event: React.MouseEvent<HTMLDivElement, MouseEvent>) => void;
}
declare const InfoBar: ({ type, message, onClick, showClose }: InfoBarProps) => React.JSX.Element;
export default InfoBar;
