export { default } from "./InfoBar";
