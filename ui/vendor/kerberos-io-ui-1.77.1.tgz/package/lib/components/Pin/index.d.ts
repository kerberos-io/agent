export { default } from "./Pin";
