import React from "react";
import "./pinnedbadge.scss";
export interface PinProps {
    pin: string;
    status: string;
    round?: boolean;
}
declare const Pin: ({ pin, status, round }: PinProps) => React.JSX.Element;
export default Pin;
