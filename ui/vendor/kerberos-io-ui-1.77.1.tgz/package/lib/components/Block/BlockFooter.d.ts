import React from "react";
import "./block.scss";
export interface BlockFooterProps {
    children?: any;
}
declare const BlockFooter: ({ children }: BlockFooterProps) => React.JSX.Element;
export default BlockFooter;
