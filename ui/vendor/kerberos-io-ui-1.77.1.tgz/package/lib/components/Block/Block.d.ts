import React from "react";
import "./block.scss";
export interface BlockProps {
    children?: any;
}
declare const Block: ({ children }: BlockProps) => React.JSX.Element;
export default Block;
