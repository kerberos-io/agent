import React from "react";
import "./block.scss";
export interface BlockHeaderProps {
    children?: any;
}
declare const BlockHeader: ({ children }: BlockHeaderProps) => React.JSX.Element;
export default BlockHeader;
