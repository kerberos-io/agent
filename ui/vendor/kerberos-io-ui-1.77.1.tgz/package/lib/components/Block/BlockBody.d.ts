import React from "react";
import "./block.scss";
export interface BlockBodyProps {
    children?: any;
}
declare const BlockBody: ({ children }: BlockBodyProps) => React.JSX.Element;
export default BlockBody;
