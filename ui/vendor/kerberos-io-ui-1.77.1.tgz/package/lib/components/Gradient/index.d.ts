export { default } from "./Gradient";
