import React from "react";
import "./gradient.scss";
export interface GradientProps {
}
/**
 * Primary UI component for user interaction
 */
declare const Gradient: ({}: GradientProps) => React.JSX.Element;
export default Gradient;
